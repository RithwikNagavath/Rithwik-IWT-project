# 🏠 RealtyVerse – AI-Powered Real Estate Frontend

**Created by: Nagavath Rithwik**

RealtyVerse is a professional-grade real estate frontend web application built with HTML, CSS, and JavaScript. It features property browsing, intelligent filtering, AI search prompts, login modal, and sleek UI with a beautiful background.

## 🚀 Features

- Responsive design for desktop and mobile
- High-resolution background from Unsplash
- Property cards with price, image, and action buttons
- Favorites and Compare sections
- AI Assistant input field (demo logic)
- Modal login popup
- Sorting and filtering system (in development)

## 📁 Project Structure

```
/realtyverse-frontend/
├── index.html
├── styles.css
├── script.js
└── README.md
```

## 🛠️ How to Run

1. Clone the repo or download ZIP  
2. Place all files in a folder  
3. Open `index.html` in your browser
