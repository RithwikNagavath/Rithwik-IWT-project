const properties = [
  {
    title: "Luxury Villa - Hyderabad",
    price: 7500000,
    img: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80"
  },
  {
    title: "Modern Apartment - Bangalore",
    price: 5500000,
    img: "https://images.unsplash.com/photo-1570129477492-45c003edd2be?auto=format&fit=crop&w=800&q=80"
  }
];

/* JavaScript logic omitted for brevity (same as previous response) */
