# 🏠 RealtyVerse Backend (Enhanced)

This backend includes:
- ✅ MongoDB integration
- 🔐 User authentication (JWT)
- 🧾 Secure API routes for properties

## ▶️ Usage

1. Set up `.env` with your Mongo URI and JWT_SECRET
2. Run `npm install`
3. Start with `npm start`

## API Endpoints

- `POST /api/auth/signup`
- `POST /api/auth/login`
- `GET /api/properties`
- `POST /api/properties` (auth required)

## 🔗 Example `.env`
```
MONGO_URI=mongodb+srv://<user>:<pass>@cluster0.mongodb.net/realtyverse
JWT_SECRET=supersecretkey12345
```
