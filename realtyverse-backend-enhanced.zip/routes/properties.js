const router = require('express').Router();
const Property = require('../models/Property');
const auth = require('../middleware/auth');

router.get('/', async (req, res) => {
  const props = await Property.find().populate('postedBy','name');
  res.json(props);
});

router.post('/', auth, async (req, res) => {
  const newProp = new Property({ ...req.body, postedBy: req.user.id });
  await newProp.save();
  res.status(201).json(newProp);
});

module.exports = router;
