const jwt = require('jsonwebtoken');
module.exports = (req, res, next) => {
  const bearer = req.header('Authorization');
  if (!bearer) return res.status(401).end();
  const token = bearer.split(' ')[1];
  try {
    const data = jwt.verify(token, process.env.JWT_SECRET);
    req.user = data;
    next();
  } catch {
    res.status(401).end();
  }
};
