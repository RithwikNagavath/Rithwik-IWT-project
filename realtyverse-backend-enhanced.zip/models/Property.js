const mongoose = require('mongoose');
const propertySchema = new mongoose.Schema({
  title: String,
  price: Number,
  img: String,
  postedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
});
module.exports = mongoose.model('Property', propertySchema);
